#include <stdio.h>

int a=99;

int  A =9;


double square(double x){
	return x*x;
}

int main(){
	int x = 100;
	//unsigned y = (unsigned)x;
	printf("x= %x\n",x);//
	x >> 2;
	printf("shift x = %x\n", x);	
	//printf("%c\n", x);
}

