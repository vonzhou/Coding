#include <stdio.h>


#define f(x) ((x) - 1)


int main(){
	printf("%d\n", f(3));

	printf("%d\n", f (3));
	return 0;
}
