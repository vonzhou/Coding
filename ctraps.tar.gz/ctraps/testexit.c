#include <stdio.h>
#include <stdlib.h>


void func(){

	exit(-1);
}


int main(){
	func();
	return 0;
}
