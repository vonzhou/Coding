#include <stdio.h>

int main(){


	putchar('a');
	putchar('b');


	return 0;
}
