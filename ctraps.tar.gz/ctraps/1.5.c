#include <stdio.h>

int main(){
	char x = 'yes';
	printf("%d\n", x);
	printf("%d\n", 's');
}
