#include <stdio.h>

struct logrec{
	int data;
	int time;
	int code;
}


main(){

	printf("hello vonzhou ...\n");
	return 0;// error 	
}

