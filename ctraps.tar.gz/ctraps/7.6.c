#include <stdio.h>
#include <stdlib.h>

int main(){
	char *p;
	p = NULL;
	printf("Location 0 contains %d\n", *p);

	return 0;
}
