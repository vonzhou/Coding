#include <stdio.h>
#include <stdlib.h>

int main(){
	char *p;
	//p = NULL;
	
	printf("Location 0 contains %d\n", RAND_MAX);

	return 0;
}
