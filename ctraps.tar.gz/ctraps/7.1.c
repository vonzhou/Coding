#include <stdio.h>

int a=99;

int  A =9;


double square(double x){
	return x*x;
}

int main(){
	
	printf("%g\n", square(3));
}

